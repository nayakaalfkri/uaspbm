import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

// Pastikan 'kampus_jasa_app' sama dengan nama di pubspec.yaml
import 'package:kampus_jasa_app/main.dart';

void main() {
  testWidgets('Login screen UI test', (WidgetTester tester) async {
    // Build our app and trigger a frame.
    await tester.pumpWidget(const JasaApp());

    // Verifikasi bahwa halaman login menampilkan judul utama.
    expect(find.text('Kampus Jasa'), findsOneWidget);

    // Verifikasi bahwa ada input field untuk email.
    // Disesuaikan menjadi 'Email Kampus'
    expect(find.widgetWithText(TextFormField, 'Email Kampus'), findsOneWidget);

    // Verifikasi bahwa ada tombol Login.
    expect(find.widgetWithText(ElevatedButton, 'Login'), findsOneWidget);

    // Verifikasi bahwa TIDAK ADA teks '1' di layar.
    expect(find.text('1'), findsNothing);
  });
}