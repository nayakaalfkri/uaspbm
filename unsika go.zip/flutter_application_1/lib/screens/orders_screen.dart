import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';

class OrdersScreen extends StatefulWidget {
  const OrdersScreen({super.key});

  @override
  State<OrdersScreen> createState() => _OrdersScreenState();
}

class _OrdersScreenState extends State<OrdersScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Pesanan Saya'),
        automaticallyImplyLeading: false,
        bottom: TabBar(
          controller: _tabController,
          labelColor: Colors.deepPurple,
          unselectedLabelColor: Colors.grey,
          indicatorColor: Colors.deepPurple,
          indicatorSize: TabBarIndicatorSize.tab,
          tabs: const [
            Tab(text: 'Sedang Berjalan'),
            Tab(text: 'Riwayat'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _buildOngoingOrdersList(),
          _buildHistoryOrdersList(),
        ],
      ),
    );
  }

  Widget _buildOngoingOrdersList() {
    final List<Map<String, String>> ongoingOrders = [
      {'service': 'Antar Orang', 'driver': 'Budi Hartono', 'status': 'Menuju lokasi penjemputan'},
      {'service': 'Antar Makanan', 'driver': 'Siti Nurhaliza', 'status': 'Pesanan sedang disiapkan'},
    ];

    if (ongoingOrders.isEmpty) {
      return const Center(child: Text('Tidak ada pesanan aktif.'));
    }
    
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: ongoingOrders.length,
      itemBuilder: (context, index) {
        final order = ongoingOrders[index];
        return Card(
          margin: const EdgeInsets.only(bottom: 16),
          child: ListTile(
            contentPadding: const EdgeInsets.all(16),
            leading: Icon(_getServiceIcon(order['service']!), color: Colors.deepPurple, size: 40),
            title: Text(order['service']!, style: const TextStyle(fontWeight: FontWeight.bold)),
            subtitle: Text('${order['driver']!}\nStatus: ${order['status']!}'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () {},
          ),
        );
      },
    ).animate().fadeIn(duration: 500.ms);
  }

  Widget _buildHistoryOrdersList() {
    final List<Map<String, String>> historyOrders = [
      {'service': 'Antar Barang', 'driver': 'Dodi Firmansyah', 'date': '08 Okt 2025', 'price': 'Rp 25.000'},
      {'service': 'Antar Orang', 'driver': 'Citra Ayu', 'date': '07 Okt 2025', 'price': 'Rp 15.000'},
    ];

    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: historyOrders.length,
      itemBuilder: (context, index) {
        final order = historyOrders[index];
        return Card(
          margin: const EdgeInsets.only(bottom: 16),
          child: ListTile(
            contentPadding: const EdgeInsets.all(16),
            leading: Icon(_getServiceIcon(order['service']!), color: Colors.grey, size: 40),
            title: Text(order['service']!, style: const TextStyle(fontWeight: FontWeight.bold)),
            subtitle: Text('${order['driver']!} - ${order['date']!}'),
            trailing: Text(order['price']!, style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.black87)),
            onTap: () {},
          ),
        );
      },
    ).animate().fadeIn(duration: 500.ms);
  }

  IconData _getServiceIcon(String serviceName) {
    switch (serviceName) {
      case 'Antar Orang': return Icons.drive_eta_rounded;
      case 'Antar Barang': return Icons.inventory_2_rounded;
      case 'Antar Makanan': return Icons.fastfood_rounded;
      default: return Icons.miscellaneous_services;
    }
  }
}