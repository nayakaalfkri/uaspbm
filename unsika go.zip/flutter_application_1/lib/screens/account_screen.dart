import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'login_screen.dart';

class AccountScreen extends StatelessWidget {
  const AccountScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Akun Saya'),
        automaticallyImplyLeading: false,
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16)
            ),
            child: Column(
              children: [
                const CircleAvatar(
                  radius: 50,
                  backgroundImage: NetworkImage('https://i.pravatar.cc/150?img=10'),
                ),
                const SizedBox(height: 16),
                const Text(
                  'Nama Mahasiswa',
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 4),
                const Text(
                  'mahasiswa@kampus.ac.id',
                  style: TextStyle(fontSize: 16, color: Colors.grey),
                ),
              ],
            ),
          ).animate().fadeIn(duration: 500.ms).scaleXY(begin: 0.9),
          
          const SizedBox(height: 24),
          const Text('Umum', style: TextStyle(color: Colors.grey, fontWeight: FontWeight.w600)),
          const SizedBox(height: 10),
          _buildMenuTile(
            icon: Icons.person_outline_rounded,
            title: 'Edit Profil',
            onTap: () {},
          ),
          _buildMenuTile(
            icon: Icons.settings_outlined,
            title: 'Pengaturan Aplikasi',
            onTap: () {},
          ),
          
          const SizedBox(height: 24),
          const Text('Bantuan', style: TextStyle(color: Colors.grey, fontWeight: FontWeight.w600)),
          const SizedBox(height: 10),
           _buildMenuTile(
            icon: Icons.help_outline_rounded,
            title: 'Pusat Bantuan',
            onTap: () {},
          ),
          _buildMenuTile(
            icon: Icons.info_outline_rounded,
            title: 'Tentang Aplikasi',
            onTap: () {},
          ),
          const Divider(height: 40),

          ElevatedButton.icon(
            icon: const Icon(Icons.logout_rounded),
            label: const Text('Logout'),
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red.shade400),
            onPressed: () {
              Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(builder: (context) => const LoginScreen()),
                (Route<dynamic> route) => false,
              );
            },
          ),
        ].animate(interval: 100.ms).slideX(begin: -0.1).fadeIn(),
      ),
    );
  }

  Widget _buildMenuTile({required IconData icon, required String title, VoidCallback? onTap}) {
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: ListTile(
        leading: Icon(icon, color: Colors.deepPurple),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w500)),
        trailing: const Icon(Icons.chevron_right_rounded, color: Colors.grey),
        onTap: onTap,
      ),
    );
  }
}