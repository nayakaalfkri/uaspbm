import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';

class RegistrationScreen extends StatelessWidget {
  const RegistrationScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Buat Akun Baru'),
      ),
      body: ListView(
        padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 20.0),
        children: <Widget>[
          const SizedBox(height: 24.0),
          _buildTextField(label: 'Nama Lengkap', icon: Icons.person_outline),
          const SizedBox(height: 16.0),
          _buildTextField(label: 'Email Kampus', icon: Icons.email_outlined, keyboardType: TextInputType.emailAddress),
          const SizedBox(height: 16.0),
          _buildTextField(label: 'Nomor Telepon', icon: Icons.phone_outlined, keyboardType: TextInputType.phone),
          const SizedBox(height: 16.0),
          _buildTextField(label: 'Buat Password', icon: Icons.lock_outline, obscureText: true),
          const SizedBox(height: 32.0),
          ElevatedButton(
            child: const Text('Daftar'),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
        ].animate(interval: 100.ms).slideX(begin: -0.2).fadeIn(),
      ),
    );
  }

  Widget _buildTextField({required String label, required IconData icon, bool obscureText = false, TextInputType keyboardType = TextInputType.text}) {
    return TextFormField(
      obscureText: obscureText,
      keyboardType: keyboardType,
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: Icon(icon),
      ),
    );
  }
}