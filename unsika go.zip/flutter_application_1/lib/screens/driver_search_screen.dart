import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'chat_screen.dart';

class DriverSearchScreen extends StatelessWidget {
  final String serviceTitle;

  const DriverSearchScreen({super.key, required this.serviceTitle});

  final List<Map<String, String>> _allDrivers = const [
    {'name': 'Budi Hartono', 'rating': '4.8', 'distance': '1.2 km', 'faculty': 'Fakultas Ilmu Komputer', 'avatar': 'https://i.pravatar.cc/150?img=1', 'service': 'Antar Orang'},
    {'name': 'Citra Ayu', 'rating': '4.9', 'distance': '1.5 km', 'faculty': 'Fakultas Hukum', 'avatar': 'https://i.pravatar.cc/150?img=2', 'service': 'Antar Orang'},
    {'name': 'Dodi Firmansyah', 'rating': '4.7', 'distance': '2.1 km', 'faculty': 'Fakultas Ekonomi dan Bisnis', 'avatar': 'https://i.pravatar.cc/150?img=3', 'service': 'Antar Barang'},
    {'name': 'Rina Wulandari', 'rating': '4.8', 'distance': '2.5 km', 'faculty': 'Fakultas Ilmu Pemerintahan', 'avatar': 'https://i.pravatar.cc/150?img=4', 'service': 'Antar Barang'},
    {'name': 'Asep Saepudin', 'rating': '4.6', 'distance': '3.0 km', 'faculty': 'Fakultas Agama Islam', 'avatar': 'https://i.pravatar.cc/150?img=5', 'service': 'Antar Makanan'},
    {'name': 'Siti Nurhaliza', 'rating': '4.9', 'distance': '0.8 km', 'faculty': 'Fakultas Ilmu Komputer', 'avatar': 'https://i.pravatar.cc/150?img=6', 'service': 'Antar Makanan'},
  ];

  @override
  Widget build(BuildContext context) {
    final List<Map<String, String>> filteredDrivers = _allDrivers.where((driver) {
      return driver['service'] == serviceTitle;
    }).toList();

    return Scaffold(
      appBar: AppBar(
        title: Text(serviceTitle),
      ),
      body: filteredDrivers.isEmpty
          ? const Center(
              child: Text('Maaf, tidak ada driver tersedia.', style: TextStyle(fontSize: 16, color: Colors.grey)),
            )
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: filteredDrivers.length,
              itemBuilder: (context, index) {
                final driver = filteredDrivers[index];
                return Card(
                  margin: const EdgeInsets.only(bottom: 16),
                  child: Padding(
                    padding: const EdgeInsets.all(12.0),
                    child: Row(
                      children: [
                        CircleAvatar(
                          radius: 30,
                          backgroundImage: NetworkImage(driver['avatar']!),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(driver['name']!, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                              const SizedBox(height: 4),
                              Text(driver['faculty']!, style: TextStyle(color: Colors.grey.shade600, fontSize: 12)),
                              const SizedBox(height: 4),
                              Row(
                                children: [
                                  const Icon(Icons.star, color: Colors.amber, size: 16),
                                  Text(' ${driver['rating']}'),
                                  const SizedBox(width: 12),
                                  const Icon(Icons.route_outlined, color: Colors.grey, size: 16),
                                  Text(' ${driver['distance']}'),
                                ],
                              ),
                            ],
                          ),
                        ),
                        IconButton(
                          icon: const Icon(Icons.chevron_right_rounded),
                          color: Colors.deepPurple,
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(builder: (context) => const ChatScreen()),
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                ).animate().fadeIn(delay: (100 * index).ms, duration: 500.ms).slideX(begin: -0.2);
              },
            ),
    );
  }
}