import 'package:flutter/material.dart';
import 'api_service.dart';

class AdminPage extends StatefulWidget {
  const AdminPage({super.key});

  @override
  State<AdminPage> createState() => _AdminPageState();
}

class _AdminPageState extends State<AdminPage> {
  // Fungsi Refresh Data agar setelah hapus/tambah list langsung berubah
  void refreshData() {
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Kelola Menu (Penjual)"),
        backgroundColor: Colors.redAccent,
      ),
      body: FutureBuilder<List<dynamic>>(
        future: ApiService.getMenu(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(child: Text("Belum ada menu. Silakan tambah!"));
          }

          return ListView.builder(
            itemCount: snapshot.data!.length,
            itemBuilder: (context, index) {
              final menu = snapshot.data![index];
              return Card(
                margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                child: ListTile(
                  leading: const Icon(Icons.edit_note, size: 40, color: Colors.blueGrey),
                  title: Text(menu['nama_makanan'], style: const TextStyle(fontWeight: FontWeight.bold)),
                  subtitle: Text("Rp ${menu['harga']}"),
                  
                  // FITUR CRUD (Edit & Hapus)
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      // Tombol Edit
                      IconButton(
                        icon: const Icon(Icons.edit, color: Colors.blue),
                        onPressed: () => _showFormDialog(context, menu),
                      ),
                      // Tombol Hapus
                      IconButton(
                        icon: const Icon(Icons.delete, color: Colors.red),
                        onPressed: () async {
                          bool confirm = await showDialog(
                            context: context, 
                            builder: (ctx) => AlertDialog(
                              title: const Text("Hapus Menu?"),
                              actions: [
                                TextButton(onPressed: ()=>Navigator.pop(ctx, false), child: const Text("Batal")),
                                TextButton(onPressed: ()=>Navigator.pop(ctx, true), child: const Text("Hapus")),
                              ],
                            )
                          ) ?? false;

                          if(confirm) {
                            await ApiService.hapusMenu(menu['id']);
                            refreshData(); // Refresh UI
                          }
                        },
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
      // TOMBOL TAMBAH MENU
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.redAccent,
        child: const Icon(Icons.add),
        onPressed: () => _showFormDialog(context, null),
      ),
    );
  }

  // --- LOGIKA FORM POPUP (Sama seperti sebelumnya) ---
  void _showFormDialog(BuildContext context, Map? menu) {
    final nameController = TextEditingController(text: menu != null ? menu['nama_makanan'] : '');
    final priceController = TextEditingController(text: menu != null ? menu['harga'] : '');
    final descController = TextEditingController(text: menu != null ? menu['deskripsi'] : '');

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text(menu == null ? "Tambah Menu Baru" : "Edit Menu"),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(controller: nameController, decoration: const InputDecoration(labelText: "Nama Makanan")),
              TextField(controller: priceController, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: "Harga (Angka)")),
              TextField(controller: descController, decoration: const InputDecoration(labelText: "Deskripsi Singkat")),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text("Batal")),
            ElevatedButton(
              onPressed: () async {
                if (menu == null) {
                  await ApiService.tambahMenu(nameController.text, priceController.text, descController.text);
                } else {
                  await ApiService.editMenu(menu['id'], nameController.text, priceController.text, descController.text);
                }
                Navigator.pop(context);
                refreshData(); // PENTING: Refresh setelah simpan
              },
              child: const Text("Simpan"),
            ),
          ],
        );
      },
    );
  }
}