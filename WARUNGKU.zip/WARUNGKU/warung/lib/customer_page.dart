import 'package:flutter/material.dart';
import 'api_service.dart';

class CustomerPage extends StatefulWidget {
  const CustomerPage({super.key});

  @override
  State<CustomerPage> createState() => _CustomerPageState();
}

class _CustomerPageState extends State<CustomerPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Menu Warung (Pelanggan)"),
        backgroundColor: Colors.green,
      ),
      body: FutureBuilder<List<dynamic>>(
        future: ApiService.getMenu(), // Panggil data dari API
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(child: Text("Belum ada menu tersedia."));
          }

          return ListView.builder(
            itemCount: snapshot.data!.length,
            itemBuilder: (context, index) {
              final menu = snapshot.data![index];
              return Card(
                margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                child: ListTile(
                  leading: const Icon(Icons.fastfood, size: 40, color: Colors.orange),
                  title: Text(menu['nama_makanan'], style: const TextStyle(fontWeight: FontWeight.bold)),
                  // Format harga biar ada Rp-nya
                  subtitle: Text("${menu['deskripsi']}\nRp ${menu['harga']}"),
                  isThreeLine: true,
                ),
              );
            },
          );
        },
      ),
    );
  }
}