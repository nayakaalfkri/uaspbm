import 'package:flutter/material.dart';
import 'customer_page.dart'; // Import halaman customer
import 'admin_page.dart';    // Import halaman admin

void main() {
  runApp(const MaterialApp(
    debugShowCheckedModeBanner: false,
    home: WelcomeScreen(),
  ));
}

class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.storefront, size: 100, color: Colors.orange),
            const SizedBox(height: 20),
            const Text(
              "WARUNGKU",
              style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold),
            ),
            const Text("Pilih peran anda untuk masuk"),
            const SizedBox(height: 50),

            // TOMBOL MASUK SEBAGAI PEMBELI
            SizedBox(
              width: 250,
              height: 50,
              child: ElevatedButton.icon(
                style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
                icon: const Icon(Icons.person, color: Colors.white),
                label: const Text("MASUK SEBAGAI PEMBELI", style: TextStyle(color: Colors.white)),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => const CustomerPage()),
                  );
                },
              ),
            ),
            
            const SizedBox(height: 20),

            // TOMBOL MASUK SEBAGAI PENJUAL
            SizedBox(
              width: 250,
              height: 50,
              child: ElevatedButton.icon(
                style: ElevatedButton.styleFrom(backgroundColor: Colors.redAccent),
                icon: const Icon(Icons.admin_panel_settings, color: Colors.white),
                label: const Text("MASUK SEBAGAI PENJUAL", style: TextStyle(color: Colors.white)),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => const AdminPage()),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}