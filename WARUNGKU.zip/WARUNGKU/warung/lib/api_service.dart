import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter/foundation.dart'; // Untuk kIsWeb

class ApiService {
  // --- KONFIGURASI IP ADDRESS ---
  static String get baseUrl {
    if (kIsWeb) {
      return "http://localhost/api"; // Untuk Browser
    } else {
      // PENTING: Emulator Android WAJIB pakai 10.0.2.2
      // Jika pakai HP Fisik (USB), ganti dengan IP Laptop (contoh: 192.168.1.5)
      return "http://10.0.2.2/api"; 
    }
  }

  // 1. GET DATA
  static Future<List<dynamic>> getMenu() async {
    try {
      final response = await http.get(Uri.parse("$baseUrl/read.php"));
      if (response.statusCode == 200) {
        return json.decode(response.body);
      }
      return [];
    } catch (e) {
      print("Error GetMenu: $e");
      return [];
    }
  }

  // 2. TAMBAH DATA (Dengan Pengecekan Error)
  static Future<bool> tambahMenu(String nama, String harga, String desc) async {
    try {
      print("Mengirim data ke: $baseUrl/create.php"); // Cek URL di Console
      
      final response = await http.post(
        Uri.parse("$baseUrl/create.php"), 
        body: {
          "nama_makanan": nama,
          "harga": harga,
          "deskripsi": desc,
        }
      );

      print("Status Code: ${response.statusCode}");
      print("Respon Server: ${response.body}"); // <-- LIHAT INI DI DEBUG CONSOLE

      var data = json.decode(response.body);
      
      // Mengembalikan true jika success == true
      return data['success'] ?? false;
      
    } catch (e) {
      print("ERROR KONEKSI: $e"); // Jika muncul ini, berarti masalah IP/Manifest
      return false;
    }
  }

  // 3. EDIT DATA
  static Future<bool> editMenu(String id, String nama, String harga, String desc) async {
    try {
      final response = await http.post(Uri.parse("$baseUrl/action.php"), body: {
        "aksi": "update",
        "id": id,
        "nama_makanan": nama,
        "harga": harga,
        "deskripsi": desc,
      });
      var data = json.decode(response.body);
      return data['success'] ?? false;
    } catch (e) {
      print("Error Edit: $e");
      return false;
    }
  }

  // 4. HAPUS DATA
  static Future<bool> hapusMenu(String id) async {
    try {
      final response = await http.post(Uri.parse("$baseUrl/action.php"), body: {
        "aksi": "delete",
        "id": id,
      });
      var data = json.decode(response.body);
      return data['success'] ?? false;
    } catch (e) {
      print("Error Hapus: $e");
      return false;
    }
  }
}