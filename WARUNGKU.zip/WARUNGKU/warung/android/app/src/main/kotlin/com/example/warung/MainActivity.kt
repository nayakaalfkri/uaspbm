package com.example.warung

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
