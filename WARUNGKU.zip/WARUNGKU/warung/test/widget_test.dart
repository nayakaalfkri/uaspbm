import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

// GANTI 'warungku' DENGAN NAMA YANG ADA DI PUBSPEC.YAML KAMU
// Contoh: import 'package:flutter_application_1/main.dart';
import 'package:warung/main.dart'; 

void main() {
  testWidgets('Cek aplikasi jalan', (WidgetTester tester) async {
    // Membangun aplikasi
    // Pastikan 'WelcomeScreen' atau class utama di main.dart kamu dipanggil disini
    await tester.pumpWidget(const MaterialApp(home: WelcomeScreen()));
  });
}